/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package ShapesLib;

import java.awt.Graphics2D;
import java.awt.Color;
import java.awt.Paint;

/**
 *
 * @author 270742
 */
public abstract class Shape2D extends Geom
{
    protected int x;
    protected int y;
    protected int width;
    protected int length;
    protected boolean isFilled;
    protected Color colour;
    protected Color lineColour;
    protected float lineThickness;
    protected Paint paint;
    protected boolean hasGrad = false;
    
    public int getX()
    {
        return x;
    }
    
    public int getY()
    {
        return y;
    }
    
    public int getWidth()
    {
        return width;
    }
    
    public int getLength()
    {
        return length;
    }
    
    public boolean getIsFilled()
    {
        return isFilled;
    }
    
    public void setX(int newX)
    {
        if (newX >= 0)
            x=newX;
    }
    
    public void setY(int newY)
    {
        if (newY >= 0)
            y=newY;
    }
    
    public void setPos(int newX, int newY)
    {
        if (newX >= 0)
            x=newX;
        if (newY >= 0)
            y=newY;
    }
    
    public void setWidth(int newWidth)
    {
        width = newWidth;
    }
    
    public void setLength(int newLength)
    {
        length = newLength;
    }
    
    public void shiftX(int shift)
    {
        x += shift;
    }
    
    public void shiftY(int shift)
    {
        y += shift;
    }
    
    public void setIsFilled(boolean set)
    {
        isFilled = set;
    }
    
    public void toggleIsFilled()
    {
        isFilled = !isFilled;
    }
    
    public void setColour(java.awt.Color newColour)
    {
        colour = newColour;
    }
    
    public void setLineColour(java.awt.Color newColour)
    {
        lineColour = newColour;
    }
    
    public void setPaint(Paint newPaint)
    {
        paint = newPaint;
        hasGrad = true;
    }
    
    public void clearPaint()
    {
        paint = null;
        hasGrad = false;
    }
    
    public void setLineThickness(float newLineThickness)
    {
        lineThickness = newLineThickness;
    }
    
    public Shape2D()
    {
        x = 0;
        y = 0;
        width = 0;
        length = 0;
        colour = Color.BLACK;
        lineColour = Color.BLACK;
        lineThickness = 1.0f;
    }
    public Shape2D(int newX, int newY, int newWidth, int newLength)
    {
        x = newX;
        y = newY;
        width = newWidth;
        length = newLength;
        colour = Color.BLACK;
        lineColour = Color.BLACK;
        lineThickness = 1.0f;
    }
    

    public abstract void draw(Graphics2D g);
    
    public abstract void update();
}

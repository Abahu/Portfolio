/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package ShapesLib;

import java.awt.Graphics2D;

/**
 *
 * @author 270742
 */
public class Ellipse extends Shape2D
{
    public Ellipse()
    {
        super();
    }
    public Ellipse(int newX, int newY, int semiMajor, int semiMinor)
    {
        super(newX, newY, semiMajor, semiMinor);
    }
    
    
    @Override
    public void draw(Graphics2D g)
    {
        java.awt.geom.Ellipse2D myEllipse = new java.awt.geom.Ellipse2D.Float(x-width,y-length,width*2,length*2);
        g.setStroke(new java.awt.BasicStroke(lineThickness));
        g.setColor(colour);
        if(hasGrad)
        {
            g.setPaint(paint);
        }
        else
        {
            g.setColor(lineColour);
        }
        if (isFilled)
                g.fill(myEllipse);
        g.draw(myEllipse);
    }
    
    @Override
    public void update()
    {
        
    }
}

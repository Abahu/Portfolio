/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package ShapesLib;

import java.lang.Math;
/**
 *
 * @author 270742
 */
public class EquiTriangle extends Triangle{
    float sideLength;
    boolean isFlipped;
    
    public void toggleIsFlipped()
    {
        isFlipped = !isFlipped;
    }
    
    public EquiTriangle()
    {
        isFlipped = false;
        sideLength = 0;
        vertices[0] = new Point(x,y);
        vertices[1] = new Point(x,y);
        vertices[2] = new Point(x,y);
    }
    public EquiTriangle(float newSideLength)
    {
        isFlipped = false;
        sideLength = newSideLength;
        vertices[0] = new Point(x,y);
        vertices[1] = new Point();
        vertices[2] = new Point();
    }
    public EquiTriangle(float newSideLength, boolean flipped)
    {
        isFlipped = flipped;
        vertices[0] = new Point(x,y);
        vertices[1] = new Point();
        vertices[2] = new Point();
    }
    public EquiTriangle(Circle scrib, boolean inscribe, boolean flipped)
    {
        isFlipped = flipped;
        float gamma = (float)(scrib.getLength()*Math.sqrt(3)/4);
        float lambda = scrib.getLength()/4;
        int flipper = (isFlipped) ? -1 : 1;
        x = scrib.getX()+scrib.getLength()/2;
        y = scrib.getY()+scrib.getLength()/2;
        vertices[0] = new Point(x,(y-flipper*scrib.getLength()/2));
        vertices[1] = new Point(x-gamma,y+flipper*lambda);
        vertices[2] = new Point(x+gamma,y+flipper*lambda);
    }
    public EquiTriangle(Circle scrib)
    {
        isFlipped = false;
        float gamma = (float)(scrib.getLength()*Math.sqrt(3)/4);
        float lambda = scrib.getLength()/4;
        int flipper = (isFlipped) ? -1 : 1;
        x = scrib.getX();
        y = scrib.getY();
        vertices[0] = new Point(x,(y-flipper*scrib.getLength()/2));
        vertices[1] = new Point(x-gamma,y+flipper*lambda);
        vertices[2] = new Point(x+gamma,y+flipper*lambda);
    }
}

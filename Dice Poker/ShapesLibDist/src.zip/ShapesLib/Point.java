/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package ShapesLib;

/**
 *
 * @author 270742
 */
public class Point extends Geom
{
    private float x;
    private float y;
    
    public float[] getPos()
    {
        float[] ret = {x,y};
        return ret;
    }
    
    public float getX()
    {
        return x;
    }
    
    public float getY()
    {
        return y;
    }
    
    public void setPos(float newX, float newY)
    {
        x = newX;
        y = newY;
    }
    
    public void setPos(int[] newPos)
    {
        x = (float) newPos[0];
        y = (float) newPos[1];
    }
    
    public void setPos(float[] newPos)
    {
        x = newPos[0];
        y = newPos[1];
    }
    
    public Point()
    {
        x = 0;
        y = 0;
    }
    
    public Point(float newX, float newY)
    {
        x = newX;
        y = newY;
    }
    
    public void draw(java.awt.Graphics2D g)
    {
        g.setColor(java.awt.Color.GREEN);
        g.drawLine((int)(x-5), (int)(y), (int)(x+5), (int)(y));
        g.drawLine((int)(x), (int)(y-5), (int)(x), (int)(y+5));
    }
    
    public void update()
    {
        
    }
}

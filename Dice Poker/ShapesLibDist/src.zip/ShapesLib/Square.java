/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package ShapesLib;

/**
 *
 * @author 270742
 */
public class Square extends RektAngle
{
    private int[] centre = new int[2];
    
    private void updateCentre()
    {
        centre[0] = x + width/2;
        centre[1] = y + length/2;
    }
    
    public int[] getCentre()
    {
        updateCentre();
        return centre;
    }
    
    public Square()
    {
        super();
        updateCentre();
    }
    
    public Square(int newX, int newY, int newWidth)
    {
        super(newX, newY, newWidth, newWidth);
        updateCentre();
    }
    
    public Square(Circle scrib)
    {
        centre[0] = scrib.getX();
        centre[1] = scrib.getY();
        width = scrib.getWidth();
        length = width;
    }
}

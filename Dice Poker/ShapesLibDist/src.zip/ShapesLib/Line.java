/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package ShapesLib;

import java.awt.Graphics2D;

/**
 *
 * @author 270742
 */
public class Line extends Geom
{
    private Point[] points = new Point[2];
    private float lineThickness;
    private java.awt.Color colour;
    
    public Point[] getPoints()
    {
        return points;
    }
    
    public void setPoints(Point[] newPoints)
    {
        points = newPoints;
    }
    
    public void setPoints(Point p1, Point p2)
    {
        points = new Point[] {p1,p2};
    }
    
    public void draw(Graphics2D g)
    {
        java.awt.geom.Line2D line = new java.awt.geom.Line2D.Float(
                points[0].getX(),
                points[0].getY(),
                points[1].getX(),
                points[1].getY());
        g.setColor(colour);
        g.setStroke(new java.awt.BasicStroke(lineThickness));
        g.draw(line);
    }
    
    public void setPointPos(float newX, float newY, int pointIndex)
    {
        points[pointIndex].setPos(newX, newY);
    }
    
    public void setLineThickness(float newLineThickness)
    {
        lineThickness = newLineThickness;
    }
    
    public void setColour(java.awt.Color newColour)
    {
        colour = newColour;
    }
    
    public Line()
    {
        points[0].setPos(0,0);
        points[1].setPos(0,0);
        lineThickness = 1.0f;
        colour = java.awt.Color.BLACK;
    }
    
    public Line(float x1, float y1, float x2, float y2)
    {
        points[0] = new Point(x1, y1);
        points[1] = new Point(x2, y2);
        lineThickness = 1.0f;
        colour = java.awt.Color.BLACK;
    }
    
    public Line(Point p1, Point p2)
    {
        points = new Point[] {p1,p2};
        lineThickness = 1.0f;
        colour = java.awt.Color.BLACK;
    }
    
    public Line(Point[] newPoints)
    {
        points = newPoints;
        lineThickness = 1.0f;
        colour = java.awt.Color.BLACK;
    }
    
    public void update()
    {
        
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package ShapesLib;

/**
 *
 * @author 270742
 */
public class Triangle extends Shape2D
{
    Point[] vertices = new Point[3];
    public Triangle()
    {
        vertices[0] = new Point();
        vertices[1] = new Point();
        vertices[2] = new Point();
    }
    public Triangle(float x1, float y1, float x2, float y2, float x3, float y3)
    {
        vertices[0] = new Point(x1,y1);
        vertices[1] = new Point(x2,y2);
        vertices[2] = new Point(x3,y3);
    }
    
    @Override
    public void draw(java.awt.Graphics2D g)
    {
        /*
        Line[] lines = new Line[3];
        lines[0] = new Line(vertices[0],vertices[1]);
        lines[1] = new Line(vertices[1],vertices[2]);
        lines[2] = new Line(vertices[2],vertices[0]);
        for(byte i = 0; i < 3; i++)
        {
            lines[i].draw(g);
        }*/
        int[] xV = {(int)vertices[0].getX(),(int)vertices[1].getX(),(int)vertices[2].getX()};
        int[] yV = {(int)vertices[0].getY(),(int)vertices[1].getY(),(int)vertices[2].getY()};
        int n = 3;
        java.awt.Polygon p = new java.awt.Polygon(xV, yV, n);
        g.setStroke(new java.awt.BasicStroke(lineThickness));
        g.setColor(lineColour);
        if(hasGrad)
        {
            g.setPaint(paint);
        }
        else
        {
            g.setColor(colour);
        }
        if (isFilled)
                g.fillPolygon(p);
        g.drawPolygon(p);
    }
    
    public void update()
    {
        
    }
    
}

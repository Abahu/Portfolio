/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package ShapesLib;

/**
 *
 * @author 270742
 */
public class Circle extends Ellipse
{
    public void setRadius(int newRadius)
    {
        width = newRadius;
        length = newRadius;
    }
    public Circle()
    {
        super();
    }
    
    public Circle(int newX, int newY, int radius)
    {
        super(newX, newY, radius, radius);
    }
}

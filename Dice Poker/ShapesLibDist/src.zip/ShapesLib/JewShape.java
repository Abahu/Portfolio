/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package ShapesLib;

/**
 *
 * @author 270742
 */
public class JewShape extends Geom
{
    float gamma;
    float lambda;
    float x;
    float y;
    float lineThickness = 1.0f;
    boolean isFilled = false;
    Point[][] vertices = new Point[2][3];
    
    java.awt.Color colour = java.awt.Color.BLUE;
    java.awt.Color lineColour = java.awt.Color.BLUE;
    
    public void setColour(java.awt.Color newColour)
    {
        colour = newColour;
    }
    
    public void setLineColour(java.awt.Color newLineColour)
    {
        lineColour = newLineColour;
    }
    
    public void setLineThickness(float newLineThickness)
    {
        lineThickness = newLineThickness;
    }
    
    public JewShape()
    {
        gamma = 0;
        lambda = 0;
        x = 0;
        y = 0;
    }
    
    public JewShape(Circle scrib, boolean inscribe)
    {
        gamma = (float)(scrib.getLength()*Math.sqrt(3)/4);
        lambda = scrib.getLength()/4;
        x = scrib.getX()+scrib.getLength()/2;
        y = scrib.getY()+scrib.getLength()/2;
        vertices[0][0] = new Point(x,(y-scrib.getLength()/2));
        vertices[0][1] = new Point(x-gamma,y+lambda);
        vertices[0][2] = new Point(x+gamma,y+lambda);
        vertices[1][0] = new Point(x,(y+scrib.getLength()/2));
        vertices[1][1] = new Point(x-gamma,y-lambda);
        vertices[1][2] = new Point(x+gamma,y-lambda);
    }
    
    public void drawJew(java.awt.Graphics2D g)
    {
        int[] xV1 = {(int)vertices[0][0].getX(),(int)vertices[0][1].getX(),(int)vertices[0][2].getX()};
        int[] yV1 = {(int)vertices[0][0].getY(),(int)vertices[0][1].getY(),(int)vertices[0][2].getY()};
        int[] xV2 = {(int)vertices[1][0].getX(),(int)vertices[1][1].getX(),(int)vertices[1][2].getX()};
        int[] yV2 = {(int)vertices[1][0].getY(),(int)vertices[1][1].getY(),(int)vertices[1][2].getY()};
        int n = 3;
        java.awt.Polygon p1 = new java.awt.Polygon(xV1, yV1, n);
        java.awt.Polygon p2 = new java.awt.Polygon(xV2, yV2, n);
        g.setStroke(new java.awt.BasicStroke(lineThickness));
        g.setColor(colour);
        if (isFilled)
        {
            g.fillPolygon(p1);
            g.fillPolygon(p2);
        }
        g.setColor(lineColour);
        g.drawPolygon(p1);
        g.drawPolygon(p2);
    }
    
    public void draw(java.awt.Graphics2D g)
    {
        drawJew(g);
    }
    
    public void update()
    {
        
    }
}

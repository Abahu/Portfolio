/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package ShapesLib;


import java.awt.Graphics2D;


/**
 *
 * @author 270742
 */
public class RektAngle extends Shape2D
{
    public RektAngle()
    {
        super();
    }
    
    public RektAngle(int newX, int newY, int newWidth, int newLength)
    {
        super(newX, newY, newWidth, newLength);
    }
    
    
    
    @Override
    public void draw(Graphics2D g)
    {
        java.awt.Rectangle myRektem = new java.awt.Rectangle(x, y, width, length);
        g.setStroke(new java.awt.BasicStroke(lineThickness));
        g.setColor(lineColour);
        if (hasGrad)
        {
            g.setPaint(paint);
        }
        else
        {
            g.setColor(colour);
            
        }
        if (isFilled)
                g.fill(myRektem); //That was a beautiful accident
        
        g.draw(myRektem);
    }
    
    public void update()
    {
        
    }
}
